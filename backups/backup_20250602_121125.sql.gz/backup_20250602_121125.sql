--
-- PostgreSQL database dump
--

-- Dumped from database version 12.22 (Debian 12.22-1.pgdg120+1)
-- Dumped by pg_dump version 12.22 (Debian 12.22-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: MedalState; Type: TYPE; Schema: public; Owner: mendoariel
--

CREATE TYPE public."MedalState" AS ENUM (
    'VIRGIN',
    'ENABLED',
    'DISABLED',
    'DEAD',
    'REGISTER_PROCESS',
    'PENDING_CONFIRMATION',
    'INCOMPLETE',
    'REGISTERED'
);


ALTER TYPE public."MedalState" OWNER TO mendoariel;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: mendoariel
--

CREATE TYPE public."Role" AS ENUM (
    'VISITOR',
    'FRIAS_EDITOR',
    'REGISTER'
);


ALTER TYPE public."Role" OWNER TO mendoariel;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: mendoariel
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'PENDING',
    'DISABLED'
);


ALTER TYPE public."UserStatus" OWNER TO mendoariel;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: mendoariel
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO mendoariel;

--
-- Name: medals; Type: TABLE; Schema: public; Owner: mendoariel
--

CREATE TABLE public.medals (
    id integer NOT NULL,
    status public."MedalState" NOT NULL,
    image text,
    description text,
    medal_string text NOT NULL,
    pet_name text NOT NULL,
    register_hash text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    owner_id integer NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.medals OWNER TO mendoariel;

--
-- Name: medals_id_seq; Type: SEQUENCE; Schema: public; Owner: mendoariel
--

CREATE SEQUENCE public.medals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.medals_id_seq OWNER TO mendoariel;

--
-- Name: medals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mendoariel
--

ALTER SEQUENCE public.medals_id_seq OWNED BY public.medals.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: mendoariel
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    hash text NOT NULL,
    username text,
    role public."Role" NOT NULL,
    hash_to_register text NOT NULL,
    phonenumber text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    hash_password_recovery text,
    hashed_rt text,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_status public."UserStatus" NOT NULL
);


ALTER TABLE public.users OWNER TO mendoariel;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: mendoariel
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO mendoariel;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mendoariel
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: virgin_medals; Type: TABLE; Schema: public; Owner: mendoariel
--

CREATE TABLE public.virgin_medals (
    id integer NOT NULL,
    status public."MedalState" NOT NULL,
    medal_string text NOT NULL,
    register_hash text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone
);


ALTER TABLE public.virgin_medals OWNER TO mendoariel;

--
-- Name: virgin_medals_id_seq; Type: SEQUENCE; Schema: public; Owner: mendoariel
--

CREATE SEQUENCE public.virgin_medals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.virgin_medals_id_seq OWNER TO mendoariel;

--
-- Name: virgin_medals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mendoariel
--

ALTER SEQUENCE public.virgin_medals_id_seq OWNED BY public.virgin_medals.id;


--
-- Name: medals id; Type: DEFAULT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.medals ALTER COLUMN id SET DEFAULT nextval('public.medals_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: virgin_medals id; Type: DEFAULT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.virgin_medals ALTER COLUMN id SET DEFAULT nextval('public.virgin_medals_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: mendoariel
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
afc1b407-12db-4436-a800-233c5264e3a6	90a3d9f693c726e738af3f27942597d1090837c767f08a3d0c64c0e79ae10085	2025-05-30 13:24:18.633211+00	20250212125507_add_status_registered_for_medals	\N	\N	2025-05-30 13:24:18.627844+00	1
3c103d40-8b88-4585-b524-52872c93eae9	fb14918d28facaeaaced783304f7f3990dbd6b3ecb878b04598684118dcbef65	2025-05-30 13:24:18.431028+00	20240523202948_first	\N	\N	2025-05-30 13:24:18.420672+00	1
a5f9f964-7a59-44d9-8d6c-887ecfa2bb9a	bb1c851264c2c75e4178c62823fbdf35d057ab84f4728043f1fcb4bc168427a0	2025-05-30 13:24:18.497494+00	20250205222948_update	\N	\N	2025-05-30 13:24:18.493946+00	1
f28ceee0-d7ad-4299-b6eb-fa166f8c2d4b	af7bc931cf585214d2edf46be64d1bcdf413b38f82bffcc6b029495ab2117fd9	2025-05-30 13:24:18.437658+00	20240524135120_add_username	\N	\N	2025-05-30 13:24:18.432113+00	1
9df71675-9965-40f0-93cf-71f75b6df00e	1662fdc87e508924c7d85c684076a44dbe860488d9d4884fc2a283f1d52333d3	2025-05-30 13:24:18.442634+00	20240603180619_role_enum	\N	\N	2025-05-30 13:24:18.438687+00	1
83aa4872-b8ea-4886-b038-beeabf70f44e	0b729b6bc23b71080fce0754a58337b3254f66186809a3cfa3c26b00e4ece558	2025-05-30 13:24:18.577025+00	20250210132518_new	\N	\N	2025-05-30 13:24:18.571179+00	1
228aa171-928d-4026-8522-bfdc0bc4fc38	0178969a40f0d3d36e996bd1dce011ec7478dc6021226911ff6109b5d56089e7	2025-05-30 13:24:18.446847+00	20240604194136_change_superpower	\N	\N	2025-05-30 13:24:18.443683+00	1
27307372-d380-444a-9473-d1c11a357d9e	79a1103d2ed60f3f3126f86bbfd8a83ab6158561615224400231005c3871b64e	2025-05-30 13:24:18.508376+00	20250206125527_new_migration	\N	\N	2025-05-30 13:24:18.49878+00	1
61968104-22ed-42a1-a574-0721e2ac1711	2f251faa7ed276e2abece1cba3ca00605d1abcf659576c4bb8d0f2140fc55b47	2025-05-30 13:24:18.450772+00	20240625163121_add_hash_password_recovery	\N	\N	2025-05-30 13:24:18.447838+00	1
a0b9346e-c8f7-4ed6-8cd0-c7f5b3ba9ebc	1a671b1e1d64b829cc0380c9ad6e7ffc91779af4ac51d6fb5bf28719e0e4db6a	2025-05-30 13:24:18.45858+00	20250203195901_create_medals_table	\N	\N	2025-05-30 13:24:18.4519+00	1
e323fa33-494a-4b41-8345-0a622ac6bd44	f4eea05bd42700a5ddb71b9367495463889c4c926b6bf9c363a2cc5f8a9bf416	2025-05-30 13:24:18.463984+00	20250203200852_fix_medal_table	\N	\N	2025-05-30 13:24:18.459567+00	1
9b8d0554-bbdd-48db-84a6-96e967b3aac3	ccebed371765ea9aa8d19e8e1096bff94c4eb4fa6b03e548f71de990dea3c53c	2025-05-30 13:24:18.515507+00	20250207131538_create_relationship	\N	\N	2025-05-30 13:24:18.509443+00	1
0cfbd463-9fe6-4f2d-98aa-ea1fbaeac0dc	4419ed7b149fd85bec442cfd2e5465165c097280466eb784a5de7080157d73b4	2025-05-30 13:24:18.468699+00	20250205154515_add_hash_register_into_table_medal	\N	\N	2025-05-30 13:24:18.465168+00	1
c42962f9-25e3-44d9-aa3f-28d24f0658a9	c7f38867468994672f9b8650c6a2723df86d2077c3bfe31062fd35f01ffe81a5	2025-05-30 13:24:18.473153+00	20250205175150_add_a_status_register_process	\N	\N	2025-05-30 13:24:18.469892+00	1
a2ae7bba-9931-4ddc-9449-3d28654fe29f	122d743a0403e77ad7e0ed9447f5b8826f2fbdbc55612d936eff004dd13c2eec	2025-05-30 13:24:18.476545+00	20250205213228_migrate_to_fix	\N	\N	2025-05-30 13:24:18.474254+00	1
048391e7-0b39-46d6-9c5e-42d0babb9d05	4be05d75cc16ce90f1ebda6ea12dc74bfb8af5bcf866a70416a337bc2d65eb7d	2025-05-30 13:24:18.521623+00	20250207134701_relationship_2	\N	\N	2025-05-30 13:24:18.516619+00	1
339b5d44-b7f1-4710-8caf-392cc3ef98d6	7cc733cb96be5cf3660f81fe84f30b973aefc0196164e761df0d25d24eafdbb4	2025-05-30 13:24:18.48343+00	20250205220458_	\N	\N	2025-05-30 13:24:18.477577+00	1
80bbe708-8aec-48f6-a166-ca7c9f6ccdbd	fba3fdedffcebcb440baa0c0a757fd8245353ca357016516311f5e2b64151dc4	2025-05-30 13:24:18.488445+00	20250205220807_new	\N	\N	2025-05-30 13:24:18.484604+00	1
1a164a42-bdfa-4397-8d20-0f5fdb280a6b	6accebd3bed00887f78a9fdcfff4f7670b047f6b2a77bee6f118a9a9afeda7a5	2025-05-30 13:24:18.586812+00	20250210153117_use_user_table	\N	\N	2025-05-30 13:24:18.578705+00	1
e601b7cf-958c-413a-8c71-ebb857c03434	c6cedeb28c17bff2a99f615aaa08ff4e49046a71f2c6af2a8366a3b36154e07f	2025-05-30 13:24:18.492953+00	20250205222901_more_changes	\N	\N	2025-05-30 13:24:18.489709+00	1
bf137e2b-22d2-4311-996d-6f9464a5d036	f4d7aab64ed356eb2d010e4cf9de4015b2990ee1a93e816c95a25badfcfbb5d5	2025-05-30 13:24:18.53418+00	20250207141115_new_migration	\N	\N	2025-05-30 13:24:18.523199+00	1
a31999ef-c38e-4f33-af08-bfc0158e70d4	1988b7102925ae459f3b5ffe022c57b1c13466215c2a89b63edc4f254330b5da	2025-05-30 13:24:18.54442+00	20250207164913_	\N	\N	2025-05-30 13:24:18.535428+00	1
cc9626c8-ea6c-4a84-8fd0-35cc18715da9	935fbaec6cd4b9381d043544bcbfa7023bc55ea2f6d89bd813d0d4201a0a100f	2025-05-30 13:24:18.557336+00	20250207225857_new	\N	\N	2025-05-30 13:24:18.545697+00	1
b9b883f6-1046-4ae6-80a9-1909f0499e0c	d0c279bd9bfa23c16e4df0e56dae2fd70b3f8f8b462fb06d88fae6d00b6dffa7	2025-05-30 13:24:18.593905+00	20250210154702_change_name_state	\N	\N	2025-05-30 13:24:18.588571+00	1
4abe0186-0dac-45a1-b171-c294988f09ca	92bb2fb38a341a41821489d105057d603abf67e2efbc43e7f7778cd98c6facbd	2025-05-30 13:24:18.562842+00	20250207235203_user_status	\N	\N	2025-05-30 13:24:18.558686+00	1
e3816dd4-e648-4bcb-affd-d22ab274e0da	c9f9a023c7db127a3a3c2eb9832e2a7d855ffd8abea74dad65d5a9181561cf4e	2025-05-30 13:24:18.569742+00	20250208000558_name_pet_add	\N	\N	2025-05-30 13:24:18.564416+00	1
f290f8c8-f38f-4cc7-ae3a-7d6955aacdba	1747df81adb58e612a2a35d560f1e776902529971a4d073396e541306534511a	2025-05-30 13:24:18.641136+00	20250212152437_name_pet	\N	\N	2025-05-30 13:24:18.635068+00	1
c6e04ac7-e9da-4784-902c-71747ce7be5f	ccbc7a792b5f909a0069813d2963fd1375f9fb9c052b7a2d7a78c00ac44fb02a	2025-05-30 13:24:18.601189+00	20250210171208_use_user_table	\N	\N	2025-05-30 13:24:18.595692+00	1
6a81a966-a248-483c-a222-1525cff57d4e	ef7a3e1e3546e9635e290e87f000ad0bed7d35b417c6b4b4c03bc19e57f75902	2025-05-30 13:24:18.625996+00	20250211164257_tuesday_11_migration	\N	\N	2025-05-30 13:24:18.602831+00	1
6002d782-b5c9-4643-beed-7f10df66b97b	27a9b546fa4fac8d4c2db069fc910fd886f8c4fe3e33842594ae9f710e985ea5	2025-05-30 13:24:18.673579+00	20250311182708_add_phone_and_description	\N	\N	2025-05-30 13:24:18.660743+00	1
b27758eb-b3b2-45bd-baa4-d5fa47aba68a	01348597f415540d15308f2a043308fbcf49613445643fc6421d627cf0a2f8d2	2025-05-30 13:24:18.650073+00	20250222212635_update_optional	\N	\N	2025-05-30 13:24:18.643566+00	1
4882e068-d755-41ce-8a43-e0cf4eb08e1b	fcde0a0bcde85b44462f1650a4a1360f6090b684e5fae98bcab95b93c1b2b533	2025-05-30 13:24:18.692499+00	20250527182942_maps_names	\N	\N	2025-05-30 13:24:18.682879+00	1
1978a8c5-c691-4640-8b96-eefd35f4d413	8f78bc2a35fe922fb8e14a6bda599877085e75a914ed3e086e1ddf5e59b10e8e	2025-05-30 13:24:18.658878+00	20250222215600_images_fiel_into_medals	\N	\N	2025-05-30 13:24:18.652543+00	1
b9d890a1-599b-4bdf-aab4-5b922fcf4ffd	f22d85a61ed01ac17ecbe7a3556053bb58960f166ec912f93b84f0df5fbe4bda	2025-05-30 13:24:18.680745+00	20250311184006_optional_description_of_the_medal	\N	\N	2025-05-30 13:24:18.675234+00	1
\.


--
-- Data for Name: medals; Type: TABLE DATA; Schema: public; Owner: mendoariel
--

COPY public.medals (id, status, image, description, medal_string, pet_name, register_hash, created_at, owner_id, updated_at) FROM stdin;
1	ENABLED	20250530134218-2k6eeel1hd108n.jpg	Vivo en el barrio supe, mi familia esta preocupara por mi.	rosa_mosqueta	Rosa Mosqueta	viernes	2025-05-30 13:40:57.827	1	2025-05-30 13:40:57.827
2	ENABLED	2025053013546-glftf4l6r5zupi.jpg	Gata que se porta muy bien, la queremos mucho.	pilar	Maria del Pilar	viernes\n	2025-05-30 13:47:29.792	2	2025-05-30 13:47:29.792
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mendoariel
--

COPY public.users (id, email, hash, username, role, hash_to_register, phonenumber, created_at, hash_password_recovery, hashed_rt, updated_at, user_status) FROM stdin;
1	mendoariel@hotmail.com	$2a$10$DMhyXE8/sYioTOjmlQDF2.SwOzUOAR/hPH7zvMgDgRIDGjhqFrEzK	\N	VISITOR	76zt6xpb0iyw7halg7o0dsgtshztnm31smf4	2615597977	2025-05-30 13:40:57.827	\N	\N	2025-05-30 13:40:57.827	ACTIVE
2	mendoariel@gmail.com	$2a$10$.Mr9m8EB5LXfyKU.okMBUe2MhnyQVtOdRhkOONJnue0TC03uHntZe	\N	VISITOR	bgavoq2sw09qalz1ufj4ctvalyw4vlpe8fpe	2615597977	2025-05-30 13:47:29.792	\N	$2a$10$sFsoT1hiX5cWUoyOBngNGuq0PNVRWS5TvQDHCg3lZwk2a6ZgrVFbe	2025-05-30 13:47:29.792	ACTIVE
\.


--
-- Data for Name: virgin_medals; Type: TABLE DATA; Schema: public; Owner: mendoariel
--

COPY public.virgin_medals (id, status, medal_string, register_hash, created_at, updated_at) FROM stdin;
1	ENABLED	rosa_mosqueta	viernes	2025-05-30 13:40:21.584	\N
2	ENABLED	pilar	viernes\n	2025-05-30 13:45:39.24	\N
\.


--
-- Name: medals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mendoariel
--

SELECT pg_catalog.setval('public.medals_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mendoariel
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: virgin_medals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mendoariel
--

SELECT pg_catalog.setval('public.virgin_medals_id_seq', 2, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: medals medals_pkey; Type: CONSTRAINT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.medals
    ADD CONSTRAINT medals_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: virgin_medals virgin_medals_pkey; Type: CONSTRAINT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.virgin_medals
    ADD CONSTRAINT virgin_medals_pkey PRIMARY KEY (id);


--
-- Name: medals_medal_string_key; Type: INDEX; Schema: public; Owner: mendoariel
--

CREATE UNIQUE INDEX medals_medal_string_key ON public.medals USING btree (medal_string);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: mendoariel
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: virgin_medals_medal_string_key; Type: INDEX; Schema: public; Owner: mendoariel
--

CREATE UNIQUE INDEX virgin_medals_medal_string_key ON public.virgin_medals USING btree (medal_string);


--
-- Name: medals medals_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mendoariel
--

ALTER TABLE ONLY public.medals
    ADD CONSTRAINT medals_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

